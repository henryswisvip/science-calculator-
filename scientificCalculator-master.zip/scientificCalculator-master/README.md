# Scientific Calculator
This is a web based Scientific Calculator using Html Css and Javascript

It is Hosted on Firebase Hosting using Nodejs
