function dis(n1){
			calci.display.value+=n1;
		}
function calc(){
			calci.display.value=eval(calci.display.value);
        }
       